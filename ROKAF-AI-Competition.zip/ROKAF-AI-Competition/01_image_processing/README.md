## Image Processing Fundamentals (NumPy & OpenCV)

This folder contains core image-processing techniques commonly required in practical data-science and computer-vision tests.

### Skills Demonstrated
- Image loading and visualization
- Normalization and noise reduction
- Edge detection and thresholding
- Morphological operations
- Contour detection and bounding box extraction
- Building clean preprocessing pipelines

### Relevance to ROKAF AI Competition
These techniques form the foundation of image-based preprocessing tasks and are directly applicable to time-limited notebook assessments.
