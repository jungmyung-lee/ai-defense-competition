## Object Detection with YOLO (Inference → Fine-tuning)

This folder focuses on **YOLO-based object detection**, covering both inference and transfer learning workflows.

### Skills Demonstrated
- YOLO model loading and inference
- Threshold and NMS tuning
- Visualization of detections (boxes, labels, confidence)
- Video inference pipelines
- Custom dataset formatting (YOLO format)
- Transfer learning setup and training log interpretation

### Relevance to ROKAF AI Competition
Object detection is a common applied AI task. These notebooks emphasize practical deployment-style steps under realistic constraints.
