## Text Preprocessing & Classification (Practical NLP)

This folder contains short, practical notebooks for turning raw text into a working classifier.

### Skills Demonstrated
- Text cleaning and tokenization
- Stopword handling and normalization
- Vectorization (Bag-of-Words, TF-IDF)
- Baseline classifiers (Logistic Regression, Naive Bayes)
- Evaluation (Precision, Recall, F1) and error analysis

### Relevance to ROKAF AI Competition
Text classification tasks often appear as “quick DS problems.” The focus here is robust preprocessing and clear evaluation.
