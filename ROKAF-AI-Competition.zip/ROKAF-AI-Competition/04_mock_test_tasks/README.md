## Mock Test Tasks (End-to-End, Time-Limited Style)

This folder includes compact, end-to-end notebooks designed to mimic time-limited preliminary round tasks.

### What You Will See
- Fast EDA and sanity checks
- Minimal but robust preprocessing
- Clear result reporting (metrics + short conclusions)
- Templates that can be reused for new datasets

### Relevance to ROKAF AI Competition
These notebooks prioritize *speed + correctness*—the same tradeoffs required in real preliminary tests.
