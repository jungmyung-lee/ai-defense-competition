# ROKAF AI Competition Prep — Practical Code Portfolio

This repository is a **hands-on preparation portfolio** aligned with the *ROKAF AI Competition (Preliminary Round)* style of tasks:
**computer vision**, **object detection (YOLO)**, and **text preprocessing & classification** in a **time-constrained, notebook-based** environment.

The goal is to demonstrate:
- Realistic, competition-ready **data preprocessing** and **pipeline building**
- Clear, reproducible **Jupyter Notebook** workflows
- Professional documentation and readable, well-commented code suitable for **international reviewers** (e.g., admissions officers)

> **Note:** The notebooks are designed to run with commonly available Python packages.
> Some notebooks (YOLO) include optional install steps and dataset placeholders.

## Repository Structure

- **01_image_processing/**  
  Core image-processing techniques using **NumPy + OpenCV** (filters, edges, morphology, contours, bounding boxes).

- **02_yolo_object_detection/**  
  End-to-end object detection workflows using **YOLO** (inference, video processing, thresholds, dataset formatting, transfer learning).

- **03_text_classification/**  
  Practical NLP preprocessing and classification pipelines (TF-IDF, Logistic Regression / Naive Bayes, evaluation).

- **04_mock_test_tasks/**  
  Mini “test-style” tasks that combine the above skills into **fast, end-to-end solutions**.

## How to Run

1. Open any notebook (`.ipynb`) in Jupyter / VS Code / Colab.
2. Run cells top-to-bottom.
3. For notebooks that require additional packages, follow the included install cell.

## Design Principles

- **Readable code first:** Every notebook includes a top-level summary and step-by-step commentary.
- **Competition realism:** Focus on fast, robust pipelines and practical evaluation.
- **Reusability:** Each notebook can serve as a template for new tasks and datasets.

## Contact

If you are reviewing this repository in an admissions or evaluation context and would like additional context, feel free to reach out via the GitHub profile.
